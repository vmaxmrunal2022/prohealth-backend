<?php


namespace App\Constants;

define('userData', $userData);
