<?php

namespace App\Http\Controllers\ThirdPartyPricing;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class TaxScheduleController extends Controller
{
    //
}
